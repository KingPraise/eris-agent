import { encodeFunctionData, type Address, type PublicClient } from "viem";
import { curveStableSwapNgAbi, curveTricryptoAbi, erc20Abi } from "../abis.js";
import { CURVE, TOKENS, stableBalanceOf } from "../constants.js";
import {
  mergeStableUnits,
  poolShareValueUsdc,
  type PoolReserves,
  type StableUnits,
} from "../valuation.js";
import { marketPricedStables, type StableMarket } from "../stables.js";
import {
  marketFor,
  marketsFor,
  tokenInfo,
  type MarketConfig,
} from "../markets.js";
import {
  resolveMarket,
  twoSidedFields,
  twoSidedQuote,
} from "./marketHelpers.js";
import type {
  AgentObservation,
  AmmObservation,
  BalanceSnapshot,
  CurveLeg,
  StableSwapAction,
  CurveSwapAction,
  LeafAction,
} from "../types.js";
import type {
  AgentProtocolValue,
  BuiltTx,
  ProtocolAdapter,
  SimContext,
  UnpricedHoldingDetail,
  ValidationResult,
} from "./types.js";
import { approveTx } from "./uniswap.js";

const DECIMAL_INTEGER = /^[0-9]+$/;

type CurveMarketState = {
  market: MarketConfig;
  // base/USD (name kept WETH-compatible; value is this base's price). With a two-sided probe this is
  // the executable mid = sqrt(sell*buy); if only the sell probe succeeded it is the legacy sell quote.
  priceUsdcPerWeth: number;
  // Two-sided executable quotes (unset when the buy probe failed -> consumers fall back to legacy).
  sellPriceUsdcPerWeth?: number;
  buyPriceUsdcPerWeth?: number;
  effectiveHalfSpreadBps?: number;
};

type CurveState = {
  // WETH market (kept at top level for backward compatibility).
  priceUsdcPerWeth: number;
  // All curve markets (including WETH). WETH only on the default fork.
  markets: CurveMarketState[];
};

function wethMarket(): MarketConfig {
  const m = marketFor("curve", "WETH");
  if (!m) throw new Error("curve: WETH market not configured");
  return m;
}

function legOf(market: MarketConfig): CurveLeg {
  if (!market.curve) throw new Error(`curve: market ${market.key} has no leg`);
  return market.curve;
}

// ---------------------------------------------------------------------------
// LP-token holdings (issue #41)
//
// add_liquidity is reachable through rawTx, and an LP-token balance used to contribute nothing to an
// agent's value. Pricing the share needs the pool's coin list and its LP token, both immutable for a
// deployment — so they are resolved once and cached rather than re-read for every block reconstruct
// walks back over.
// ---------------------------------------------------------------------------

export type CurvePoolShape = {
  pool: Address;
  lpToken: Address;
  coins: Address[];
};

// Highest coin count probed. Curve pools in this sim are 2 (twocrypto-ng) or 3 (tricrypto) coins.
const MAX_CURVE_COINS = 4;

const shapeCache = new Map<string, CurvePoolShape>();

async function resolveCurvePool(
  publicClient: PublicClient,
  pool: Address,
): Promise<CurvePoolShape | undefined> {
  const cached = shapeCache.get(pool.toLowerCase());
  if (cached) return cached;
  const coins: Address[] = [];
  for (let i = 0; i < MAX_CURVE_COINS; i++) {
    try {
      coins.push(
        (await publicClient.readContract({
          address: pool,
          abi: curveTricryptoAbi,
          functionName: "coins",
          args: [BigInt(i)],
        })) as Address,
      );
    } catch {
      break; // coins(i) reverts past the last coin
    }
  }
  if (coins.length === 0) return undefined;
  // Older tricrypto pools mint a separate LP token; twocrypto-ng pools are their own ERC-20.
  const lpToken = await publicClient
    .readContract({
      address: pool,
      abi: curveTricryptoAbi,
      functionName: "token",
    })
    .then((t) => t as Address)
    .catch(() => pool);
  const shape = { pool, lpToken, coins };
  shapeCache.set(pool.toLowerCase(), shape);
  return shape;
}

// The reads a pool share is valued from: every coin's balance, then the LP supply.
function curveReserveReads(shape: CurvePoolShape) {
  return [
    ...shape.coins.map((_, i) => ({
      address: shape.pool,
      abi: curveTricryptoAbi,
      functionName: "balances",
      args: [BigInt(i)],
    })),
    { address: shape.lpToken, abi: erc20Abi, functionName: "totalSupply" },
  ];
}

// Decode curveReserveReads(shape) for each shape, laid out back to back from the start of results.
// A pool with any unreadable balance, or an unreadable supply, decodes to undefined.
function decodeCurveReserves(
  shapes: readonly CurvePoolShape[],
  results: readonly unknown[],
): Array<PoolReserves | undefined> {
  let cursor = 0;
  return shapes.map((shape) => {
    const balances = results.slice(cursor, cursor + shape.coins.length);
    const totalSupply = results[cursor + shape.coins.length];
    cursor += shape.coins.length + 1;
    if (typeof totalSupply !== "bigint") return undefined;
    if (balances.some((b) => typeof b !== "bigint")) return undefined;
    return {
      tokens: shape.coins,
      balances: balances as bigint[],
      totalSupply,
    };
  });
}

// Shapes of every distinct pool across the configured curve markets. Pools that cannot be read are
// omitted, so their holdings are reported as unpriced instead of being marked wrong.
export async function resolveCurvePools(
  publicClient: PublicClient,
): Promise<CurvePoolShape[]> {
  const pools = new Map<string, Address>();
  for (const m of marketsFor("curve"))
    pools.set(legOf(m).pool.toLowerCase(), legOf(m).pool);
  const shapes = await Promise.all(
    [...pools.values()].map((p) => resolveCurvePool(publicClient, p)),
  );
  return shapes.filter((s): s is CurvePoolShape => s !== undefined);
}

// Use 0.1 base unit as the probe (small amount to limit slippage impact; price is recovered as output/probe).
function probeBaseAmount(market: MarketConfig): bigint {
  return 10n ** BigInt(tokenInfo(market.base).decimals) / 10n;
}

async function getDy(
  publicClient: PublicClient,
  leg: CurveLeg,
  i: number,
  j: number,
  dx: bigint,
): Promise<bigint> {
  return publicClient.readContract({
    address: leg.pool,
    abi: curveTricryptoAbi,
    functionName: "get_dy",
    args: [BigInt(i), BigInt(j), dx],
  }) as Promise<bigint>;
}

async function getMarketQuote(
  publicClient: PublicClient,
  market: MarketConfig,
): Promise<Omit<CurveMarketState, "market">> {
  // Sell probe: base probe amount -> quote (fee/impact-inclusive executable sell price).
  const leg = legOf(market);
  const dx = probeBaseAmount(market);
  const baseDec = tokenInfo(market.base).decimals;
  const quoteDec = tokenInfo(market.quote).decimals;
  const sellOut = await getDy(
    publicClient,
    leg,
    leg.baseIndex,
    leg.quoteIndex,
    dx,
  );
  const baseFloat = Number(dx) / 10 ** baseDec;
  const sellQuoteFloat = Number(sellOut) / 10 ** quoteDec;
  const sellPx = sellQuoteFloat / baseFloat;
  if (!(sellPx > 0)) return { priceUsdcPerWeth: 0 };
  // Buy probe: the same notional back (quote -> base) quoted on the same state. Both directions
  // together recover the executable mid and the effective per-side cost.
  try {
    const buyOut = await getDy(
      publicClient,
      leg,
      leg.quoteIndex,
      leg.baseIndex,
      sellOut,
    );
    const buyBaseFloat = Number(buyOut) / 10 ** baseDec;
    if (!(buyBaseFloat > 0)) return { priceUsdcPerWeth: sellPx };
    return twoSidedQuote(sellPx, sellQuoteFloat / buyBaseFloat);
  } catch {
    // Never fail readState harder than the legacy one-sided probe did.
    return { priceUsdcPerWeth: sellPx };
  }
}

export async function getCurveState(
  publicClient: PublicClient,
): Promise<CurveState> {
  const markets = marketsFor("curve");
  const states = await Promise.all(
    markets.map(async (m) => ({
      market: m,
      ...(await getMarketQuote(publicClient, m)),
    })),
  );
  const weth = states.find((s) => s.market.base === "WETH") ?? states[0];
  return {
    priceUsdcPerWeth: weth?.priceUsdcPerWeth ?? 0,
    markets: states,
  };
}

// Backward compatible: WETH/USDC curve price (USDC per WETH). Shared by dashboard/reconstruct.
export async function getCurvePrice(
  publicClient: PublicClient,
): Promise<number> {
  const quote = await getMarketQuote(publicClient, wethMarket());
  return quote.priceUsdcPerWeth;
}

function applySlippage(amount: bigint, slippageBps: number): bigint {
  return (amount * BigInt(10_000 - slippageBps)) / 10_000n;
}

function requireDecimalString(
  value: unknown,
  name: string,
): asserts value is string {
  if (typeof value !== "string" || !DECIMAL_INTEGER.test(value))
    throw new Error(`${name} must be a decimal integer string`);
}

// Read action.base (default WETH) and resolve the corresponding market (for parse).
function parseBase(obj: Record<string, unknown>): {
  base: string;
  market: MarketConfig;
} {
  const base = typeof obj.base === "string" ? obj.base : "WETH";
  const market = marketFor("curve", base);
  if (!market) throw new Error(`curve: no market for base "${base}"`);
  return { base, market };
}

// Issue #27 (c): the stable/stable leg. Its pool is a stableswap-ng created by the same factory as
// this venue's crypto pools, which is why it lives here rather than behind a ProtocolId of its own --
// a venue whose entire job is one pool would need a config flag and a place in every roster to say
// the same thing.
function parseStableSwap(obj: Record<string, unknown>): LeafAction | null {
  if (obj.type !== "stableSwap") return null;
  if (typeof obj.stable !== "string")
    throw new Error("stable must be a token symbol string");
  const market = stableMarketBySymbol(obj.stable);
  if (!market)
    throw new Error(
      `stableSwap: "${obj.stable}" is not a market-priced stable in this deployment ` +
        `(known: ${
          marketPricedStables()
            .map((m) => m.symbol)
            .join(", ") || "none"
        })`,
    );
  if (obj.tokenIn !== market.symbol && obj.tokenIn !== "USDC")
    throw new Error(`tokenIn must be ${market.symbol} or USDC`);
  requireDecimalString(obj.amountIn, "amountIn");
  const action: StableSwapAction = {
    type: "stableSwap",
    stable: market.symbol,
    tokenIn: obj.tokenIn,
    amountIn: obj.amountIn,
  };
  if (obj.maxPriorityFeePerGasWei !== undefined) {
    requireDecimalString(
      obj.maxPriorityFeePerGasWei,
      "maxPriorityFeePerGasWei",
    );
    action.maxPriorityFeePerGasWei = obj.maxPriorityFeePerGasWei;
  }
  if (obj.slippageBps !== undefined) {
    if (
      typeof obj.slippageBps !== "number" ||
      !Number.isInteger(obj.slippageBps) ||
      obj.slippageBps < 0 ||
      obj.slippageBps > 1000
    ) {
      throw new Error("slippageBps must be an integer between 0 and 1000");
    }
    action.slippageBps = obj.slippageBps;
  }
  return action;
}

function stableMarketBySymbol(symbol: string): StableMarket | undefined {
  return marketPricedStables().find((m) => m.symbol === symbol);
}

function parse(obj: Record<string, unknown>): LeafAction | null {
  if (obj.type === "stableSwap") return parseStableSwap(obj);
  if (obj.type !== "curveSwap") return null;
  const { base, market } = parseBase(obj);
  if (obj.tokenIn !== market.base && obj.tokenIn !== market.quote)
    throw new Error(`tokenIn must be ${market.base} or ${market.quote}`);
  requireDecimalString(obj.amountIn, "amountIn");
  const action: CurveSwapAction = {
    type: "curveSwap",
    tokenIn: obj.tokenIn,
    amountIn: obj.amountIn,
  };
  if (base !== "WETH") action.base = base;
  if (obj.maxPriorityFeePerGasWei !== undefined) {
    requireDecimalString(
      obj.maxPriorityFeePerGasWei,
      "maxPriorityFeePerGasWei",
    );
    action.maxPriorityFeePerGasWei = obj.maxPriorityFeePerGasWei;
  }
  if (obj.slippageBps !== undefined) {
    if (
      typeof obj.slippageBps !== "number" ||
      !Number.isInteger(obj.slippageBps) ||
      obj.slippageBps < 0 ||
      obj.slippageBps > 1000
    ) {
      throw new Error("slippageBps must be an integer between 0 and 1000");
    }
    action.slippageBps = obj.slippageBps;
  }
  return action;
}

// The per-round USDC cap, restated in another token's decimals. Both are dollars, so the conversion
// is the decimal difference and nothing else.
function scaleUsdcLimit(limitUsdcUnits: bigint, decimals: number): bigint {
  const quoteDecimals = TOKENS.USDC.decimals;
  if (decimals === quoteDecimals) return limitUsdcUnits;
  return decimals > quoteDecimals
    ? limitUsdcUnits * 10n ** BigInt(decimals - quoteDecimals)
    : limitUsdcUnits / 10n ** BigInt(quoteDecimals - decimals);
}

function validateStableSwap(
  action: StableSwapAction,
  obs: AgentObservation,
  balances: BalanceSnapshot,
): ValidationResult {
  const amountIn = BigInt(action.amountIn);
  if (amountIn <= 0n) return { ok: false, reason: "amountIn must be positive" };
  const market = stableMarketBySymbol(action.stable);
  if (!market)
    return { ok: false, reason: `no market for stable ${action.stable}` };
  const sellingStable = action.tokenIn === market.symbol;
  const balance = sellingStable
    ? stableBalanceOf(balances, market.token)
    : stableBalanceOf(balances, TOKENS.USDC.address);
  if (amountIn > balance)
    return { ok: false, reason: "amountIn exceeds balance" };
  return { ok: true };
}

function validate(
  action: LeafAction,
  obs: AgentObservation,
  balances: BalanceSnapshot,
): ValidationResult {
  if (action.type === "stableSwap")
    return validateStableSwap(action, obs, balances);
  if (action.type !== "curveSwap")
    return { ok: false, reason: "not a curve action" };
  const amountIn = BigInt(action.amountIn);
  if (amountIn <= 0n) return { ok: false, reason: "amountIn must be positive" };
  const base = action.base ?? "WETH";
  const market = marketFor("curve", base);
  if (!market) return { ok: false, reason: `no curve market for ${base}` };
  const inIsBase = action.tokenIn === market.base;
  // The balance is the only cap -- no per-order size limit on any venue.
  const balance = inIsBase
    ? (balances.bases?.[market.base] ?? balances.wethWei)
    : stableBalanceOf(balances, legOf(market).stable);
  if (amountIn > balance)
    return { ok: false, reason: "amountIn exceeds balance" };
  return { ok: true };
}

async function buildSwapTx(
  publicClient: PublicClient,
  market: MarketConfig,
  action: CurveSwapAction,
): Promise<BuiltTx> {
  const leg = legOf(market);
  const amountIn = BigInt(action.amountIn);
  const slippageBps = action.slippageBps ?? 50;
  const [i, j] =
    action.tokenIn === market.base
      ? [leg.baseIndex, leg.quoteIndex]
      : [leg.quoteIndex, leg.baseIndex];
  const quoted = await getDy(publicClient, leg, i, j, amountIn);
  const minDy = applySlippage(quoted, slippageBps);
  return {
    to: leg.pool,
    data: encodeFunctionData({
      abi: curveTricryptoAbi,
      functionName: "exchange",
      args: [BigInt(i), BigInt(j), amountIn, minDy],
    }),
  };
}

// Both coins of a stableswap-ng plain pool, quoted the same way a curveSwap is: read the executable
// output, then bound it by the caller's slippage. `stableIndex`/`quoteIndex` come from the registry,
// so an agent never has to know which coin the deploy put first.
async function buildStableSwapTx(
  publicClient: PublicClient,
  action: StableSwapAction,
): Promise<BuiltTx> {
  const market = stableMarketBySymbol(action.stable);
  if (!market) throw new Error(`stableSwap: no market for ${action.stable}`);
  const amountIn = BigInt(action.amountIn);
  const [i, j] =
    action.tokenIn === market.symbol
      ? [market.stableIndex, market.quoteIndex]
      : [market.quoteIndex, market.stableIndex];
  const quoted = (await publicClient.readContract({
    address: market.pool,
    abi: curveStableSwapNgAbi,
    functionName: "get_dy",
    args: [BigInt(i), BigInt(j), amountIn],
  })) as bigint;
  const minDy = applySlippage(quoted, action.slippageBps ?? 50);
  return {
    to: market.pool,
    data: encodeFunctionData({
      abi: curveStableSwapNgAbi,
      functionName: "exchange",
      args: [BigInt(i), BigInt(j), amountIn, minDy],
    }),
  };
}

export const curveAdapter: ProtocolAdapter = {
  id: "curve",
  stableToken: CURVE.usdcToken,
  parse,
  bundleable: () => true,
  validate,

  async readState(ctx): Promise<CurveState> {
    return getCurveState(ctx.publicClient);
  },

  async observe(ctx, state, _agent, fairPrice): Promise<AmmObservation> {
    const s = state as CurveState;
    const weth =
      s.markets.find((m) => m.market.base === "WETH") ?? s.markets[0];
    const obs: AmmObservation = {
      priceUsdcPerWeth: weth?.priceUsdcPerWeth ?? s.priceUsdcPerWeth,
      ...twoSidedFields(weth),
    };
    const extra: NonNullable<AmmObservation["markets"]> = {};
    for (const ms of s.markets) {
      if (ms.market.base === "WETH") continue;
      // The observation reports the pool's live price; fairPrices is only the last fallback for when
      // the probe returned nothing. The old fair-first order (baseFairPrice) pinned the observed
      // curve price to fair, so agents chased a phantom spread between the real curve price and the
      // other venues (the same bug class fixed in balancer's observe; part of the WBTC all-agent bleed).
      extra[ms.market.key] = {
        priceUsdcPerWeth:
          ms.priceUsdcPerWeth > 0
            ? ms.priceUsdcPerWeth
            : (ctx.fairPrices?.[ms.market.base] ?? ms.priceUsdcPerWeth),
        ...twoSidedFields(ms),
      };
    }
    if (Object.keys(extra).length > 0) obs.markets = extra;
    return obs;
  },

  async buildTxs(ctx, _owner, action): Promise<BuiltTx[]> {
    if (action.type === "stableSwap")
      return [await buildStableSwapTx(ctx.publicClient, action)];
    if (action.type !== "curveSwap")
      throw new Error("curve buildTxs: unexpected action");
    const market = resolveMarket("curve", action);
    return [await buildSwapTx(ctx.publicClient, market, action)];
  },

  async valueUsdc(): Promise<number> {
    return 0; // swap only. Balance is already counted on the wallet side (stable aggregate)
  },

  // Issue #41: an LP-token balance used to contribute nothing. Coin lists and LP tokens are
  // immutable, so they are resolved once outside the batched stage.
  async *valueAtBlock(ctx) {
    const empty: Record<string, AgentProtocolValue> = {};
    for (const a of ctx.agents)
      empty[a.id] = { valueUsdc: 0, liquidatableValueUsdc: 0, unpriced: [] };
    const shapes = await resolveCurvePools(ctx.publicClient);
    if (shapes.length === 0) return empty;

    const reserveReads = shapes.flatMap(curveReserveReads);
    const results = yield [
      ...reserveReads,
      ...ctx.agents.flatMap((a) =>
        shapes.map((shape) => ({
          address: shape.lpToken,
          abi: erc20Abi,
          functionName: "balanceOf",
          args: [a.address],
        })),
      ),
    ];

    const reserves = decodeCurveReserves(shapes, results);
    const cursor = reserveReads.length;

    // No median here, for the same reason as balancer's BPT: the share is a holding, not a price.
    const fairByBase = ctx.fairByBase();
    const stablePrices = ctx.stablePrices();
    const out: Record<string, AgentProtocolValue> = {};
    ctx.agents.forEach((agent, a) => {
      let valueUsdc = 0;
      const stableLongs: StableUnits = {};
      const unpriced: UnpricedHoldingDetail[] = [];
      shapes.forEach((shape, s) => {
        const balance = results[cursor + a * shapes.length + s];
        if (typeof balance !== "bigint" || balance <= 0n) return;
        const pool = reserves[s];
        if (!pool) {
          unpriced.push({
            token: shape.lpToken,
            amountRaw: balance.toString(),
            source: "curve-lp",
          });
          return;
        }
        const share = poolShareValueUsdc(
          pool,
          balance,
          fairByBase,
          stablePrices,
        );
        valueUsdc += share.valueUsdc;
        mergeStableUnits(stableLongs, share.stableUnits);
        for (const h of share.unpriced)
          unpriced.push({ ...h, source: "curve-lp" });
      });
      out[agent.id] = {
        valueUsdc,
        // remove_liquidity exits at the pool ratio without a fee, so the share is already realizable.
        liquidatableValueUsdc: valueUsdc,
        unpriced,
        ...(Object.keys(stableLongs).length > 0 ? { stableLongs } : {}),
      };
    });
    return out;
  },

  async accountedTokens(publicClient): Promise<Address[]> {
    return (await resolveCurvePools(publicClient)).map((s) => s.lpToken);
  },

  async setupWallet(): Promise<BuiltTx[]> {
    const txs: BuiltTx[] = [];
    const seen = new Set<string>();
    const approve = (token: string, spender: string) => {
      const key = `${token.toLowerCase()}:${spender.toLowerCase()}`;
      if (seen.has(key)) return;
      seen.add(key);
      txs.push(approveTx(token as `0x${string}`, spender as `0x${string}`));
    };
    for (const m of marketsFor("curve")) {
      const leg = legOf(m);
      approve(tokenInfo(m.base).address, leg.pool);
      approve(leg.stable, leg.pool);
    }
    // Issue #27 (c): the stable/stable pools, both legs. Without these a stableSwap reverts on the
    // transfer and the depeg is untradable for everyone equally, which reads as "nobody found it".
    for (const m of marketPricedStables()) {
      approve(m.token, m.pool);
      approve(TOKENS.USDC.address, m.pool);
    }
    return txs;
  },
};

export type { CurveState };
