// Shared USD valuation primitives for scoring (issue #41).
//
// The scorer used to enumerate a fixed set of position types and value everything else at exactly
// zero, so moving real value into an unlisted venue read as a total loss. These helpers price a
// holding from the token registry instead, and make "cannot price this" a reportable outcome rather
// than a silent zero.
import { formatUnits, type Address } from "viem";
import { USDC_VARIANTS } from "./constants.js";
import { tokenInfoByAddress } from "./markets.js";
import { stablePriceUsdc, type StablePrices } from "./stables.js";

// Stables the run settles in but the token registry does not name. On the Arbitrum fork the registry
// is WETH/USDC only, while the deep Balancer and Curve pools hold USDC.e and USDT -- so a BPT holder
// lost roughly a third of their value and a Curve LP lost its whole stable leg. Spot accounting
// already treats all three as 6-decimal USDC-equivalent worth $1 (constants' USDC_VARIANTS); pool
// shares have to use the same convention or the two disagree about the same token.
const STABLE_VARIANT_DECIMALS = 6;

function stableVariantDecimals(token: Address): number | undefined {
  const target = token.toLowerCase();
  for (const address of Object.values(USDC_VARIANTS)) {
    if (address.toLowerCase() === target) return STABLE_VARIANT_DECIMALS;
  }
  return undefined;
}

// Why a holding is missing from a value, or in it on an assumption.
//
// "unpriced" means the amount is known but has no USD price; "read-failed" means the read that
// would have revealed the holding failed, so the holding is *unknown* rather than zero (issue #44);
// "unrealizable" means it is known and priceable but cannot be turned into anything before the run
// ends -- an LST redemption whose queue finalizes after the last block (issue #38). Those three are
// excluded from the value.
//
// "par-fallback" is the odd one out: the holding *is* counted, at $1, because its market would not
// quote (issue #27). Par is the least wrong number -- it is the price a CDP redemption or an
// issuer's mint/burn actually enforces -- but it is an assumption, and the whole point of pricing
// stables from a market is that this environment stops making it silently.
//
// "mid-fallback" is counted too: a market-priced stable whose own-size quote did not return at any
// block of the window, so the holding is marked at the probe's mid instead of at what selling (or
// buying back) that size would realize. The mid overstates a large holding -- which is why the
// own-size quote exists -- so the fallback is said out loud.
//
// All five are reported — a zero in summary.json must never be mistaken for a trading loss, and
// neither must a dollar.
export type ScoringExclusionReason =
  | "unpriced"
  | "read-failed"
  | "unrealizable"
  | "par-fallback"
  | "mid-fallback";

// A holding left out of a value, and why.
export type UnpricedAmount = {
  // The token, when the exclusion is token-shaped. Absent when a whole position could not be read
  // (an Aave account, say, is not one token).
  token?: Address;
  // The raw token amount excluded from the value ("" when even the amount is unknown).
  amountRaw: string;
  // Defaults to "unpriced" when unset, which is what every issue #41 site reports.
  reason?: ScoringExclusionReason;
  // For "read-failed": what could not be read, e.g. "AavePool.getUserAccountData". Prose rather than
  // a taxonomy — it is read by a human diagnosing a value series, not by code.
  read?: string;
};

// USD value of a raw token amount. Bases use the run's fair price; stables use what their market
// pays, falling back to par for the numéraire and for any stable no pool quotes (issue #27).
// Undefined means the token is outside the registry, i.e. unpriceable — not worthless.
export function tokenAmountUsd(
  token: Address,
  amount: bigint,
  fairByBase: Record<string, number>,
  stablePrices?: StablePrices,
): number | undefined {
  const info = tokenInfoByAddress(token);
  if (info) {
    const price =
      info.kind === "stable"
        ? stablePriceUsdc(stablePrices, token)
        : fairByBase[info.symbol];
    if (price === undefined) return undefined;
    return Number(formatUnits(amount, info.decimals)) * price;
  }
  const stableDecimals = stableVariantDecimals(token);
  if (stableDecimals === undefined) return undefined;
  return Number(formatUnits(amount, stableDecimals));
}

// Units of each market-priced stable a mark counted at the probe's mid, keyed by lowercase token.
// The probe is a $1,000 trade, so the mid is the price of the *first* thousand dollars; a venue that
// counts a larger amount at it says how much, and the scorer re-marks the agent's whole amount --
// wallet and every venue together -- at its own-size quote (rules §4.1, the effective price at the
// holder's size). Summed across venues on purpose: a holding split between the wallet and an LP
// would otherwise be quoted as two small sales, each first in line, and the split would be worth
// more than the whole.
export type StableUnits = Record<string, bigint>;

// Add `amount` of `token` to `units` when it is a market-priced stable (one stablePrices carries a
// price for, quoted or at the par fallback). Anything else is valued at a price no trade moves --
// the reference fair, or the numéraire -- and is left alone.
export function addStableUnits(
  units: StableUnits,
  token: Address,
  amount: bigint,
  stablePrices?: StablePrices,
): void {
  if (amount <= 0n || !stablePrices) return;
  const key = token.toLowerCase();
  if (stablePrices.byToken[key] === undefined) return;
  units[key] = (units[key] ?? 0n) + amount;
}

export function mergeStableUnits(into: StableUnits, from?: StableUnits): void {
  if (!from) return;
  for (const [token, amount] of Object.entries(from))
    into[token] = (into[token] ?? 0n) + amount;
}

export type PoolReserves = {
  tokens: Address[];
  balances: bigint[];
  totalSupply: bigint;
};

// Value an LP-token holding as its proportional share of the pool's reserves.
//
// Both Balancer weighted pools and Curve crypto pools let a holder exit at the pool's own ratio
// without a swap fee, so the proportional share *is* the realizable exit value. It also avoids
// depending on a venue-specific pricing formula (virtual price, BPT rate), which would have to be
// re-derived for every pool type the sim gains.
export function poolShareValueUsdc(
  reserves: PoolReserves,
  lpBalance: bigint,
  fairByBase: Record<string, number>,
  stablePrices?: StablePrices,
): { valueUsdc: number; unpriced: UnpricedAmount[]; stableUnits: StableUnits } {
  const stableUnits: StableUnits = {};
  if (lpBalance <= 0n || reserves.totalSupply <= 0n)
    return { valueUsdc: 0, unpriced: [], stableUnits };
  let valueUsdc = 0;
  const unpriced: UnpricedAmount[] = [];
  for (let i = 0; i < reserves.tokens.length; i++) {
    const reserve = reserves.balances[i] ?? 0n;
    const amount = (reserve * lpBalance) / reserves.totalSupply;
    const usd = tokenAmountUsd(
      reserves.tokens[i],
      amount,
      fairByBase,
      stablePrices,
    );
    if (usd === undefined) {
      if (amount > 0n)
        unpriced.push({
          token: reserves.tokens[i],
          amountRaw: amount.toString(),
        });
      continue;
    }
    valueUsdc += usd;
    addStableUnits(stableUnits, reserves.tokens[i], amount, stablePrices);
  }
  return { valueUsdc, unpriced, stableUnits };
}
