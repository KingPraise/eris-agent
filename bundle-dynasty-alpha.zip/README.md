# eris agent bundle: dynasty-alpha

How to run (the environment passes the env — ERIS_RPC_URL / ERIS_AGENT_PRIVATE_KEY / ERIS_PRICE_FEED_ADDRESS, etc.):

```sh
npm install
ERIS_AGENT_DIR=agents/dynasty-alpha node --import tsx agents/runtime/bot.ts
```

`out/` carries the forge artifacts for the contracts this agent deploys, if any. That is
where the sdk's artifact reader looks; `ERIS_FORGE_OUT` overrides it.
